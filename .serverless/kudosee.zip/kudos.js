'use strict';

module.exports.list = (event, context, callback) => {
  const response = {
    statusCode: 200,
    body: JSON.stringify({
      kudos : [
        { 
            id : "1",
            name : "Helping Hand", 
            description: "This is a kudos for lending a helping hand!", 
            image: "https://goo.gl/9pShtW" 
        }
      ]
    }),
  };

  callback(null, response);
};
