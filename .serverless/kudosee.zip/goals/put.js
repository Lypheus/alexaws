/* Goals PUT Handler

   Allows for updating a goal based on json payload, this will update 
   any and all fields that it is provided, except the id.
*/

'use strict';

const AWS = require('aws-sdk'); 
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const utils = require('../utils.js');
const tableName = process.env.DYNAMODB_TABLE + "-goals";

module.exports.handler = ( event, context, callback ) => {
    var response;
    var parms = event[ "pathParameters" ];
    var payload = JSON.parse( event[ "body" ] );
    
    // check if parameters exist, if so store the {id}
    var id = null;
    if( parms && parms[ "id" ] ) {
        id = parms[ "id" ];
        console.log( "Found parameter for id: ", id );
    }

    // locate the goal with this id, otherwise we send back the list of goals
    if( id ) {
        // check that payload is valid
        if( !payload[ "name" ] || !payload[ "owner" ] || !payload[ "visibility" ] ) {
            callback( null, utils.buildResponse( 400, { error : "Must always include name, owner and visibility." } ) ); 
            return;
        }

        // check that tenantid is valid
        var tenantId = event.headers[ "tenantid" ];
        if( !tenantId ) {
            callback( null, utils.buildResponse( 400, { error : "The 'tenantid' was not found in header, cannot proceed." } ) );
            return;        
        }
        
        // here we build a condition expression which will accommodate not allowing for nullable fields (i.e. startDate, endDate)
        var updateExpression = "SET #n = :nv, #o = :ov, #v = :v";

        var exprNames = {
            "#n" : "name",
            "#o" : "owner",
            "#v" : "visibility",
            "#id" : "id",
            "#tid" : "tenantid"
        };

        var exprValues = {
            ":nv" : payload[ "name" ],
            ":ov" : payload[ "owner" ],
            ":v" : payload[ "visibility" ],
            ":id" : id,
            ":tid" : tenantId
        };

        if( payload[ "description" ] ) {
            updateExpression += ", #d = :d";
            exprNames[ "#d" ] = "description";
            exprValues[ ":d" ] = payload[ "description"];
        }

        if( payload[ "startDate" ] ) {
            updateExpression += ", #sd = :sd";
            exprNames[ "#sd" ] = "startDate";
            exprValues[ ":sd" ] = payload[ "startDate"];
        }

        if( payload[ "endDate" ] ) {
            updateExpression += ", #ed = :ed";
            exprNames[ "#ed" ] = "endDate";
            exprValues[ ":ed" ] = payload[ "endDate"];
        }

        if( payload[ "sponsors" ] ) {
            updateExpression += ", #sp = :sp";
            exprNames[ "#sp" ] = "sponsors";
            exprValues[ ":sp" ] = payload[ "sponsors"];
        }

        if( payload[ "tags" ] ) {
            updateExpression += ", #t = :t";
            exprNames[ "#t" ] = "tags";
            exprValues[ ":t" ] = payload[ "tags"];
        }

        if( payload[ "milestones" ] ) {
            updateExpression += ", #m = :m";
            exprNames[ "#m" ] = "milestones";            
            exprValues[ ":m" ] = payload[ "milestones"];
        }

        // define the parameters for this update, allow SET to determine what gets updated
        var params = {
            TableName: tableName,
            Key: {
                "id" : id
            },            
            ConditionExpression: "#id = :id and #tid = :tid",
            UpdateExpression: updateExpression,
            ExpressionAttributeValues: exprValues,
            ExpressionAttributeNames: exprNames,
            ReturnValues: "ALL_NEW"
        };
        
        dynamoDb.update(params, (error, result) => {
            if( error ) {
                callback( null, utils.buildResponse( 400, { error : error } ) );
            }
            else {
                callback( null, utils.buildResponse( 200, result ) );
            }
        });              
    }
    else {
        callback( null, utils.buildResponse( 404, { id : id, message : "Goal was not found, PUT has not saved changes." } ) );
    }
}
