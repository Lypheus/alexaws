'use strict';

const AWS = require('aws-sdk'); 
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const utils = require('../utils.js');
const tableName = process.env.DYNAMODB_TABLE + "-teams";

module.exports.handler = ( event, context, callback ) => {
    var response;
    var parms = event[ "pathParameters" ];
    var payload = JSON.parse( event[ "body" ] );
    
    // check if parameters exist, if so store the {id}
    var id = null;
    if( parms && parms[ "id" ] ) {
        id = parms[ "id" ];
        console.log( "Found parameter for id: ", id );
    }

    // locate the goal with this id, otherwise we send back the list of goals
    if( id ) {
        // check that tenantid is valid
        var tenantId = event.headers[ "tenantid" ];
        if( !tenantId ) {
            callback( null, utils.buildResponse( 400, { error : "The 'tenantid' was not found in header, cannot proceed." } ) );
            return;        
        }
        
        // here we build a condition expression which will accommodate not allowing for nullable fields (i.e. startDate, endDate)
        var updateExpression = "SET #tid = :tid";

        var exprNames = {
            "#id" : "id",
            "#tid" : "tenantid"
        };

        var exprValues = {
            ":id" : id,
            ":tid" : tenantId
        };

        if( payload[ "name" ] ) {
            updateExpression += ", #n = :nv";
            exprNames[ "#n" ] = "name";
            exprValues[ ":nv" ] = payload[ "name"];
        }

        if( payload[ "description" ] ) {
            updateExpression += ", #d = :dv";
            exprNames[ "#d" ] = "description";
            exprValues[ ":dv" ] = payload[ "description"];
        }

        if( payload[ "owner" ] ) {
            updateExpression += ", #o = :ov";
            exprNames[ "#o" ] = "owner";
            exprValues[ ":ov" ] = payload[ "owner"];
        }

        if( payload[ "members" ] ) {
            updateExpression += ", #m = :mv";
            exprNames[ "#m" ] = "members";
            exprValues[ ":mv" ] = payload[ "members"];
        }

        // define the parameters for this update, allow SET to determine what gets updated
        var params = {
            TableName: tableName,
            Key: {
                "id" : id
            },            
            ConditionExpression: "#id = :id and #tid = :tid",
            UpdateExpression: updateExpression,
            ExpressionAttributeValues: exprValues,
            ExpressionAttributeNames: exprNames,
            ReturnValues: "ALL_NEW"
        };
        
        dynamoDb.update(params, (error, result) => {
            if( error ) {
                callback( null, utils.buildResponse( 400, { error : error } ) );
            }
            else {
                callback( null, utils.buildResponse( 200, result ) );
            }
        });              
    }
    else {
        callback( null, utils.buildResponse( 404, { id : id, message : "Team was not found, PUT has not saved changes." } ) );
    }
}
