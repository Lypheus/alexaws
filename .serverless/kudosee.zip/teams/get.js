'use strict';

const AWS = require('aws-sdk'); 
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const utils = require('../utils.js');
const tableName = process.env.DYNAMODB_TABLE + "-teams";

// return a list of goals **todo : add mandatory filtering and/or pagination support
module.exports.handler = ( event, context, callback ) => {
    var response;
    var parms = event[ "pathParameters" ];
    var id = null;
    var owner = null;

    // check that tenantid is valid
    var tenantId = event.headers[ "tenantid" ];
    if( !tenantId ) {
        callback( null, utils.buildResponse( 400, { error : "The 'tenantid' was not found in header, cannot proceed." } ) );
        return;        
    }   

    // populate pagination parameter if found
    var page = null;
    if( parms && event.queryStringParameters && event.queryStringParameters[ "page" ] ) {
        page = event.queryStringParameters[ "page" ];
        console.log( "Found parameter for page: ", page );
    }

    // check if parameters exist, if so store the {id}
    if( parms && parms[ "id" ] ) {
        id = parms[ "id" ];
        console.log( "Found parameter for id: ", id );
    }

    // check for owner parameter
    if( parms && parms[ "owner" ] ) {
        owner = parms[ "owner" ];
        console.log( "Found parameter for owner: ", owner );
    }

    // check for both owner and id being null, we can't deal with it!
    if( !owner && !id ) {
        callback( null, utils.buildResponse( 404, { error : "Get must include an owner id to filter the results." } ) );
        return;
    }

    // locate the goal with this id, otherwise we send back the list of goals
    var dbParms;

    if( id ) {
        dbParms = {
            TableName : tableName,
            FilterExpression: "#tid = :tid and #id = :id",
            ProjectionExpression: "#id, #name, #description, #owner, #members",
            ExpressionAttributeNames: {
                "#tid" : "tenantid",
                "#id" : "id",
                "#name" : "name",
                "#description" : "description",
                "#owner" : "owner",
                "#members" : "members"
            },
            ExpressionAttributeValues: {
                ":tid": tenantId,
                ":id": id
            }
        };

        // if paginating, caller will include an id for page
        if( page ) {
            dbParms[ "ExclusiveStartKey" ] = { "id" : page };
        }

        console.log( "Specific GET request by ID for id=%s, tid=%s", id, tenantId );
    }
    else if( owner ) {
        dbParms = {
            TableName : tableName,
            FilterExpression: "#tid = :tid and #owner = :owner",
            ProjectionExpression: "#id, #name",
            ExpressionAttributeNames: {
                "#tid" : "tenantid",
                "#id" : "id",
                "#name" : "name",
                "#owner" : "owner"
            },
            ExpressionAttributeValues: {
                ":tid": tenantId,
                ":owner": owner
            }
        };

        // if paginating, caller will include an id for page
        if( page ) {
            dbParms[ "ExclusiveStartKey" ] = { "id" : page };
        }
        
        console.log( "Specific GET request by OWNER for owner=%s, tid=%s", owner, tenantId );
    }

    dynamoDb.scan( dbParms, (error, result) => {
        if( error ) {
            console.log( 'db error: ', error );
            callback( null, utils.buildResponse( 400, { error : error } ) );
        }
        else {
            if( Object.keys(result.Items).length < 1 ) {
                console.log( "Empty result list, object not found for id: ", id );
                callback( null, utils.buildResponse( 404, { message : "Empty list found, nothing to return." } ) );
            }
            else {
                console.log( "Found object with id: %s, returning object to caller.", id );
                callback( null, utils.buildResponse( 200, result ) );
            }
        }
    });              
}