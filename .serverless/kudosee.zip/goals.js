'use strict';

const uuid = require('uuid');
const AWS = require('aws-sdk'); // eslint-disable-line import/no-extraneous-dependencies
const dynamoDb = new AWS.DynamoDB.DocumentClient();

var goals = [];

goals.push({ id: uuid(), name: "Learn NodeJS", owner: 123, startDate: new Date(), sponsors: [ 234, 345, 456 ], tags : [ "tag1", "tag2" ], 
  description: "I'd like to learn a lot about NodeJS and develop world conquoring algorithms for that new company CyberDyne.", visibility: "public",
  milestones: [ { name : "First Milestone", completed : true }, { name : "Second Milestone", completed : false } ] });

// return a list of goals **todo : add mandatory filtering and/or pagination support
module.exports.list = ( event, context, callback ) => {
  var response;
  var payload = JSON.parse( event[ "body" ] );
  var parms = event[ "pathParameters" ];
  var id = null;

 if( event.httpMethod == "DELETE" ) {
    // mark this goal as inactive, if found.
    if( id ) {
      var index = getIndexById( goals, id );
      if (index > -1) {
        console.log( "deleting at index: ", index )
        var result = goals.splice( index, 1 );

        response = {
          statusCode: 202,
          body: JSON.stringify( result )
        };            
      } else {
        response = {
          statusCode: 404,
          body: JSON.stringify( {
            id : id,
            message : "Goal was not found, DELETE has done nothing."
          })
        };            
      }
    }
    callback( null, response );
  }
  else {
    response = {
      statusCode: 400,
      body : JSON.stringify( {
        error : "Unable to handle non PUT, POST, GET or DELETE RESTful methods."
      })
    }
    callback( null, response );
  }
};

function getValueById(arr, id) {
  for (var i=0, iLen=arr.length; i<iLen; i++) {
    if (arr[i].id == id) return arr[i];
  }

  return null;
}

function getIndexById( arr, id ) {
  if( arr.length > 0 ) {
    for (var i=0, iLen=arr.length; i<iLen; i++) {
      if (arr[i].id == id) return i;
    }  
  }

  return -1;
}