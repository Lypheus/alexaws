'use strict';

const AWS = require('aws-sdk'); 
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const utils = require('../utils.js');
const tableName = process.env.DYNAMODB_TABLE + "-profiles";

// return a list of goals **todo : add mandatory filtering and/or pagination support
module.exports.handler = ( event, context, callback ) => {
    var response;
    var parms = event[ "pathParameters" ];
    var id = null;
    var watchForId = null;
  
    // check that tenantid is valid
    var tenantId = event.headers[ "tenantid" ];
    if( !tenantId ) {
        callback( null, utils.buildResponse( 400, { error : "The 'tenantid' was not found in header, cannot proceed." } ) );
        return;        
    }   

    // check if parameters exist, if so store the {id}
    if( parms && parms[ "id" ] ) {
        id = parms[ "id" ];
        console.log( "Found parameter for id: ", id );
    }

    if( parms && parms[ "watchForId" ] ) {
        watchForId = parms[ "watchForId" ];
        console.log( "Found parameter for watchForId: ", watchForId );
    }

    if( !id && !watchForId ) {
        callback( null, utils.buildResponse( 404, { error : "Get must include an id to filter the results to the correct profile." } ) );
        return;
    }

    // locate the goal with this id, otherwise we send back the list of goals
    var dbParms;

    if( id ) {
        dbParms = {
            TableName : tableName,
            FilterExpression: "#tid = :tid and #id = :id",
            ProjectionExpression: "#id, #firstName, #lastName, #email, #avatar, #settings, #watches",
            ExpressionAttributeNames: {
                "#tid" : "tenantid",
                "#id" : "id",
                "#firstName" : "firstName",
                "#lastName" : "lastName",
                "#email" : "email",
                "#avatar" : "avatar",
                "#settings" : "settings",
                "#watches" : "watches"
            },
            ExpressionAttributeValues: {
                ":tid": tenantId,
                ":id": id
            }
        };
        
        console.log( "Specific GET request by ID for id=%s, tid=%s", id, tenantId );
    }
    else if( watchForId ) {
        dbParms = {
            TableName : tableName,
            FilterExpression: "#tid = :tid and #id = :id",
            ProjectionExpression: "#watches",
            ExpressionAttributeNames: {
                "#tid" : "tenantid",
                "#id" : "id",
                "#watches" : "watches"
            },
            ExpressionAttributeValues: {
                ":tid": tenantId,
                ":id": watchForId
            }
        };
        
        console.log( "Specific GET request by watchForId for id=%s, tid=%s", watchForId, tenantId );
    }

    dynamoDb.scan( dbParms, (error, result) => {
        if( error ) {
            console.log( 'db error: ', error );
            callback( null, utils.buildResponse( 400, { error : error } ) );
        }
        else {
            if( Object.keys(result.Items).length < 1 ) {
                console.log( "Empty result list, object not found for id: ", id );
                callback( null, utils.buildResponse( 404, { message : "Empty list found, nothing to return." } ) );
            }
            else {
                console.log( "Found object with id: %s, returning object to caller.", id );
                callback( null, utils.buildResponse( 200, result.Items ) );
            }
        }
    });              
}