'use strict';

const uuid = require('uuid');
const AWS = require('aws-sdk'); 
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const utils = require('../utils.js');
const tableName = process.env.DYNAMODB_TABLE + "-profiles";

module.exports.handler = ( event, context, callback ) => {
    var response;
    var payload = JSON.parse( event[ "body" ] );

    // check that payload is valid
    if( !payload[ "email" ] || !payload[ "firstName" ] ) {
        callback( null, utils.buildResponse( 400,{ error : "Must always include firstName and email." } ) );
        return;
    }

    // check that tenantid is valid
    var tenantId = event.headers[ "tenantid" ];
    if( !tenantId ) {
        callback( null, utils.buildResponse( 400, { error : "The 'tenantid' was not found in header, cannot proceed." } ) );
        return;        
    }

    var result = { 
        id : uuid(),
        tenantid : tenantId,
        firstName : payload[ "firstName" ],
        lastName : payload[ "lastName" ],
        email : payload[ "email" ],
        avatar : payload[ "avatar" ],
        settings : payload[ "settings" ],
        watches : payload[ "watches" ]
    };

    const params = {
        TableName: tableName,
        Item: result
    };

    dynamoDb.put(params, (error) => {
        if( error ) {
            callback( null, utils.buildResponse( 400, { error : error } ) );
        }
        else {
            callback( null, utils.buildResponse( 200, result ) );
        }
    });
}