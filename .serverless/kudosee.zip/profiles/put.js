'use strict';

const AWS = require('aws-sdk'); 
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const utils = require('../utils.js');
const tableName = process.env.DYNAMODB_TABLE + "-profiles";

module.exports.handler = ( event, context, callback ) => {
    var response;
    var parms = event[ "pathParameters" ];
    var payload = JSON.parse( event[ "body" ] );
    
    // check if parameters exist, if so store the {id}
    var id = null;
    if( parms && parms[ "id" ] ) {
        id = parms[ "id" ];
        console.log( "Found parameter for id: ", id );
    }

    // locate the goal with this id, otherwise we send back the list of goals
    if( id ) {
        // check that tenantid is valid
        var tenantId = event.headers[ "tenantid" ];
        if( !tenantId ) {
            callback( null, utils.buildResponse( 400, { error : "The 'tenantid' was not found in header, cannot proceed." } ) );
            return;        
        }
        
        // here we build a condition expression which will accommodate not allowing for nullable fields (i.e. startDate, endDate)
        var updateExpression = "SET #tid = :tid";

        var exprNames = {
            "#id" : "id",
            "#tid" : "tenantid"
        };

        var exprValues = {
            ":id" : id,
            ":tid" : tenantId
        };

        if( payload[ "firstName" ] ) {
            updateExpression += ", #n = :nv";
            exprNames[ "#n" ] = "firstName";
            exprValues[ ":nv" ] = payload[ "firstName"];
        }

        if( payload[ "lastName" ] ) {
            updateExpression += ", #ln = :lnv";
            exprNames[ "#ln" ] = "lastName";
            exprValues[ ":lnv" ] = payload[ "lastName"];
        }

        if( payload[ "email" ] ) {
            updateExpression += ", #e = :ev";
            exprNames[ "#e" ] = "email";
            exprValues[ ":ev" ] = payload[ "email"];
        }

        if( payload[ "avatar" ] ) {
            updateExpression += ", #a = :av";
            exprNames[ "#a" ] = "avatar";
            exprValues[ ":av" ] = payload[ "avatar"];
        }

        if( payload[ "settings" ] ) {
            updateExpression += ", #s = :sv";
            exprNames[ "#s" ] = "settings";
            exprValues[ ":sv" ] = payload[ "settings"];
        }

        if( payload[ "watches" ] ) {
            updateExpression += ", #wa = :wav";
            exprNames[ "#wa" ] = "watches";
            exprValues[ ":wav" ] = payload[ "watches"];            
        }

        // define the parameters for this update, allow SET to determine what gets updated
        var params = {
            TableName: tableName,
            Key: {
                "id" : id
            },            
            ConditionExpression: "#id = :id and #tid = :tid",
            UpdateExpression: updateExpression,
            ExpressionAttributeValues: exprValues,
            ExpressionAttributeNames: exprNames,
            ReturnValues: "ALL_NEW"
        };
        
        dynamoDb.update(params, (error, result) => {
            if( error ) {
                callback( null, utils.buildResponse( 400, { error : error } ) );
            }
            else {
                callback( null, utils.buildResponse( 200, result.Attributes ) );
            }
        });              
    }
    else {
        callback( null, utils.buildResponse( 404, { id : id, message : "Profile was not found, PUT has not saved changes." } ) );
    }
}
