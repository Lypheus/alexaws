'use strict';

const AWS = require('aws-sdk'); 
const dynamoDb = new AWS.DynamoDB.DocumentClient();
const utils = require('../utils.js');
const tableName = process.env.DYNAMODB_TABLE + "-awards";

// TODO: CHANGE THE {id} to {goalId}, {teamId} etc!!!

// return a list of goals **todo : add mandatory filtering and/or pagination support
module.exports.handler = ( event, context, callback ) => {
    var response;
    var parms = event[ "pathParameters" ];
    var id = null;
    var ownerId = null;
    var teamId = null;
    var goalId = null;
  
    // populate pagination parameter if found
    var page = null;
    if( parms && event.queryStringParameters && event.queryStringParameters[ "page" ] ) {
        page = event.queryStringParameters[ "page" ];
        console.log( "Found parameter for page: ", page );
    }

    // check if parameters exist, if so store the {id}
    if( parms && parms[ "id" ] ) {
        id = parms[ "id" ];
        console.log( "Found parameter for id: ", id );
    }

    // check for ownerId parameter
    console.log( "parms: " + parms[ "owner" ] );
    if( parms && parms[ "owner" ] ) {
        ownerId = parms[ "owner" ];
        console.log( "Found parameter for owner: ", ownerId );
    }

    // check for ownerId parameter
    if( parms && parms[ "team" ] ) {
        teamId = parms[ "team" ];
        console.log( "Found parameter for teamId: ", teamId );
    }

    // check for ownerId parameter
    if( parms && parms[ "goal" ] ) {
        goalId = parms[ "goal" ];
        console.log( "Found parameter for goalId: ", goalId );
    }
    
    // check that tenantid is valid
    var tenantId = event.headers[ "tenantid" ];
    if( !tenantId ) {
        callback( null, utils.buildResponse( 400, { error : "The 'tenantid' was not found in header, cannot proceed." } ) );
        return;        
    }   

    // locate the goalId with this id, otherwise we send back the list of goalIds
    var dbParms;

    if( ownerId ) {
        dbParms = {
            TableName : tableName,
            FilterExpression: "#tid = :tid and #receiver = :receiver",
            ProjectionExpression: "#id, #kudosId, #goalId, #teamId, #sender, #receiver, #comments",
            ExpressionAttributeNames: {
                "#tid" : "tenantid",
                "#id" : "id",
                "#kudosId" : "kudosId",
                "#goalId" : "goalId",
                "#sender" : "sender",
                "#receiver" : "receiver",
                "#teamId" : "teamId",
                "#comments" : "comments"
            },
            ExpressionAttributeValues: {
                ":tid": tenantId,
                ":receiver": ownerId
            }
        };

        // if paginating, caller will include an id for page
        if( page ) {
            dbParms[ "ExclusiveStartKey" ] = { "id" : page };
        }
        
        console.log( "Specific GET request by ownerId for ownerId=%s, tid=%s", ownerId, tenantId );
    }
    else if( teamId ) {
        dbParms = {
            TableName : tableName,
            FilterExpression: "#tid = :tid and #teamId = :teamId",
            ProjectionExpression: "#id, #kudosId, #goalId, #teamId, #sender, #receiver, #comments",
            ExpressionAttributeNames: {
                "#tid" : "tenantid",
                "#id" : "id",
                "#kudosId" : "kudosId",
                "#goalId" : "goalId",
                "#sender" : "sender",
                "#receiver" : "receiver",
                "#teamId" : "teamId",
                "#comments" : "comments"
            },
            ExpressionAttributeValues: {
                ":tid": tenantId,
                ":teamId": teamId
            }
        };

        // if paginating, caller will include an id for page
        if( page ) {
            dbParms[ "ExclusiveStartKey" ] = { "id" : page };
        }
        
        console.log( "Specific GET request by teamId for teamId=%s, tid=%s", teamId, tenantId );
    }
    else if( goalId ) {
        dbParms = {
            TableName : tableName,
            FilterExpression: "#tid = :tid and #goalId = :goalId",
            ProjectionExpression: "#id, #kudosId, #goalId, #teamId, #sender, #receiver, #comments",
            ExpressionAttributeNames: {
                "#tid" : "tenantid",
                "#id" : "id",
                "#kudosId" : "kudosId",
                "#goalId" : "goalId",
                "#sender" : "sender",
                "#receiver" : "receiver",
                "#teamId" : "teamId",
                "#comments" : "comments"
            },
            ExpressionAttributeValues: {
                ":tid": tenantId,
                ":goalId": goalId
            }
        };

        // if paginating, caller will include an id for page
        if( page ) {
            dbParms[ "ExclusiveStartKey" ] = { "id" : page };
        }
        
        console.log( "Specific GET request by goalId for goalId=%s, tid=%s", goalId, tenantId );
    }
    else {
        dbParms = {
            TableName : tableName,
            FilterExpression: "#tid = :tid and #id = :id",
            ProjectionExpression: "#id, #kudosId, #goalId, #teamId, #sender, #receiver, #comments",
            ExpressionAttributeNames: {
                "#tid" : "tenantid",
                "#id" : "id",
                "#kudosId" : "kudosId",
                "#goalId" : "goalId",
                "#sender" : "sender",
                "#receiver" : "receiver",
                "#teamId" : "teamId",
                "#comments" : "comments"
            },
            ExpressionAttributeValues: {
                ":tid": tenantId,
                ":id": id
            }
        };
        
        // if paginating, caller will include an id for page
        if( page ) {
            dbParms[ "ExclusiveStartKey" ] = { "id" : page };
        }

        console.log( "Specific GET request by ID for id=%s, tid=%s", id, tenantId );
    }

    dynamoDb.scan( dbParms, (error, result) => {
        if( error ) {
            console.log( 'db error: ', error );
            callback( null, utils.buildResponse( 400, { error : error } ) );
        }
        else {
            if( Object.keys(result.Items).length < 1 ) {
                console.log( "Empty result list, object not found for id: ", id );
                callback( null, utils.buildResponse( 404, { message : "Empty list found, nothing to return." } ) );
            }
            else {
                console.log( "Found object with id: %s, returning object to caller.", id );
                callback( null, utils.buildResponse( 200, result ) );
            }
        }
    });              
}